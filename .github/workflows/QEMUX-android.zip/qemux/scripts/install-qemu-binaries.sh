#!/usr/bin/env bash
# Pemakaian: scripts/install-qemu-binaries.sh <folder-hasil-build-QEMU-arm64>
# Menyalin qemu-system-* menjadi app/src/main/jniLibs/arm64-v8a/libqemu-system-*.so
# dan firmware (pc-bios) ke app/src/main/assets/qemu-share.
set -euo pipefail
SRC="${1:?folder hasil build QEMU}"
DST="$(dirname "$0")/../app/src/main"
mkdir -p "$DST/jniLibs/arm64-v8a" "$DST/assets/qemu-share"
for arch in x86_64 aarch64 riscv64; do
  f="$SRC/bin/qemu-system-$arch"
  [ -f "$f" ] && cp "$f" "$DST/jniLibs/arm64-v8a/libqemu-system-$arch.so" && echo "OK $arch"
done
# Library pendukung harus bernama lib*.so (tanpa nomor versi di belakang).
find "$SRC/lib" -maxdepth 1 -name 'lib*.so' -exec cp {} "$DST/jniLibs/arm64-v8a/" \; 2>/dev/null || true
[ -d "$SRC/share/qemu" ] && cp -r "$SRC/share/qemu/." "$DST/assets/qemu-share/"
echo "Selesai."
