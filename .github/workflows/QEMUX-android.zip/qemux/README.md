# QEMUX — QEMU untuk Android dengan Material 3 Expressive

Aplikasi baru (bukan modifikasi Limbo): Kotlin + Jetpack Compose,
`androidx.compose.material3:material3:1.4.0` (API Expressive: `MaterialExpressiveTheme`,
`HorizontalFloatingToolbar`, `ToggleButton` connected group, `MaterialShapes`, `LoadingIndicator`).

## Status (jujur)
Kode ini **belum pernah dikompilasi atau dijalankan** — ditulis tanpa Android SDK.
Kemungkinan ada galat kompilasi kecil (nama/signature API Expressive masih experimental).
Kirim log error Gradle-nya dan saya perbaiki.

## Cara build
1. Buka folder ini di Android Studio (JDK 17), tunggu Gradle sync. Jika `gradle-wrapper.jar` tidak ada: `gradle wrapper`.
2. Siapkan binary QEMU (lihat bawah), lalu Run di perangkat arm64.

## Binary QEMU (bagian tersulit)
APK hanya menjalankan `nativeLibraryDir/libqemu-system-<arch>.so` sebagai proses.
Anda perlu build QEMU 10.x/11.x untuk Android arm64, headless (`--disable-sdl --disable-gtk`, VNC aktif).
Jalur paling praktis: recipe QEMU di **termux-packages** (dirawat & versinya baru), lalu
`scripts/install-qemu-binaries.sh <hasil-build>`. Waspadai path/RPATH bawaan Termux
(`/data/data/com.termux/...`) — binary harus bisa menemukan library-nya sendiri di nativeLibraryDir.
Cek hasilnya lewat ikon chip di toolbar aplikasi (dialog "Status binary QEMU").

## Arsitektur
- `qemu/QemuCommand.kt` — menyusun argumen QEMU dari `VmConfig`
- `qemu/QemuService.kt` — foreground service, menjalankan proses, menangkap log
- `data/` — model VM + penyimpanan JSON
- `ui/` — HomeScreen, ConfigScreen, ConsoleScreen (sesuai desain)

## Belum ada
Penampil VNC bawaan (v1: sambungkan ke 127.0.0.1:59xx dengan aplikasi VNC), pembuatan disk qcow2,
file picker, KVM, dukungan x86 Android.
