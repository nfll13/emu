Letakkan libqemu-system-x86_64.so dst. di sini (lihat README.md).
