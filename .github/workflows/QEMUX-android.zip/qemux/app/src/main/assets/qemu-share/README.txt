Letakkan firmware QEMU (bios, keymaps, edk2) di sini; disalin ke filesDir/qemu-share saat pertama jalan.
