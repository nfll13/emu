package id.qemux.app.data

import android.content.Context
import org.json.JSONArray
import java.io.File

class VmRepository(ctx: Context) {
    private val file = File(ctx.filesDir, "vms.json")

    fun load(): List<VmConfig> = runCatching {
        val a = JSONArray(file.readText())
        (0 until a.length()).map { VmConfig.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun save(list: List<VmConfig>) {
        file.writeText(JSONArray(list.map { it.toJson() }).toString())
    }
}
