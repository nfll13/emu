package id.qemux.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import id.qemux.app.qemu.QemuService
import id.qemux.app.ui.ConfigScreen
import id.qemux.app.ui.ConsoleScreen
import id.qemux.app.ui.HomeScreen
import id.qemux.app.ui.theme.QemuxTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { QemuxTheme { App() } }
    }
}

@Composable
fun App(model: AppViewModel = viewModel()) {
    val vms by model.vms.collectAsStateWithLifecycle()
    val running by QemuService.running.collectAsStateWithLifecycle()
    val logs by QemuService.logs.collectAsStateWithLifecycle()
    var route by rememberSaveable { mutableStateOf("home") }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    BackHandler(route != "home") { route = "home" }

    val id = route.substringAfter(":", "")
    val current = vms.firstOrNull { it.id == id }
    when {
        route.startsWith("config:") && current != null -> ConfigScreen(
            initial = current,
            isRunning = current.id in running,
            onBack = { route = "home" },
            onSave = { model.save(it) },
            onDelete = { model.delete(current.id); route = "home" },
            onStart = { model.save(it); model.start(it); route = "console:${it.id}" },
        )
        route.startsWith("console:") && current != null -> ConsoleScreen(
            vm = current,
            since = running[current.id],
            log = logs[current.id].orEmpty(),
            onBack = { route = "home" },
            onStart = { model.start(current) },
            onStop = { model.stop(current.id) },
        )
        else -> HomeScreen(
            vms = vms,
            running = running,
            onConfig = { route = "config:${it.id}" },
            onStart = { model.start(it); route = "console:${it.id}" },
            onStop = { model.stop(it) },
            onConsole = { route = "console:${it.id}" },
            onNew = { route = "config:${model.create()}" },
        )
    }
}
