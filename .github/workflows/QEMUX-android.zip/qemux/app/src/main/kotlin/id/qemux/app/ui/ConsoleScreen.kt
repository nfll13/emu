package id.qemux.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.qemux.app.data.VmConfig

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun ConsoleScreen(
    vm: VmConfig, since: Long?, log: List<String>,
    onBack: () -> Unit, onStart: () -> Unit, onStop: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val state = rememberLazyListState()
    LaunchedEffect(log.size) { if (log.isNotEmpty()) state.animateScrollToItem(log.lastIndex) }

    Column(
        Modifier.fillMaxSize().background(cs.background).navigationBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = top + 16.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilledTonalIconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Kembali")
            }
            Text(vm.name, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f), maxLines = 1)
            if (since != null) LoadingIndicator(Modifier.size(48.dp))
        }
        Surface(shape = RoundedCornerShape(28.dp), color = cs.primaryContainer, contentColor = cs.onPrimaryContainer) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Tampilan VNC", style = MaterialTheme.typography.titleMedium)
                Text("127.0.0.1:${vm.vncPort}", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleLarge)
                Text("Sambungkan dengan aplikasi VNC di perangkat ini. Penampil bawaan belum tersedia.",
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Button(
                onClick = onStart, enabled = since == null, modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(28.dp, 8.dp, 8.dp, 28.dp),
            ) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Mulai") }
            FilledTonalButton(
                onClick = onStop, enabled = since != null, modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(8.dp, 28.dp, 28.dp, 8.dp),
            ) { Icon(Icons.Rounded.Stop, null); Spacer(Modifier.width(8.dp)); Text("Hentikan") }
        }
        Surface(Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = cs.inverseSurface, contentColor = cs.inverseOnSurface) {
            LazyColumn(state = state, contentPadding = PaddingValues(16.dp)) {
                itemsIndexed(log) { _, line -> Text(line, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp) }
            }
        }
    }
}
