package id.qemux.app.qemu

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class QemuService : Service() {
    companion object {
        const val ACTION_START = "id.qemux.START"
        const val ACTION_STOP = "id.qemux.STOP"
        const val EXTRA_ID = "id"
        const val EXTRA_CMD = "cmd"
        private const val CHANNEL = "qemu"

        /** id VM -> waktu mulai (ms). */
        val running = MutableStateFlow<Map<String, Long>>(emptyMap())
        val logs = MutableStateFlow<Map<String, List<String>>>(emptyMap())

        fun log(id: String, line: String) = logs.update { m ->
            m + (id to ((m[id] ?: emptyList()) + line).takeLast(500))
        }
    }

    private val procs = ConcurrentHashMap<String, Process>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_START -> if (id != null) {
                goForeground()
                start(id, intent.getStringArrayListExtra(EXTRA_CMD) ?: arrayListOf())
            }
            ACTION_STOP -> if (id != null) procs[id]?.destroy()
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "QEMU", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("QEMUX")
            .setContentText("Mesin virtual sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun start(id: String, cmd: List<String>) {
        if (procs.containsKey(id) || cmd.isEmpty()) return
        logs.update { it + (id to emptyList()) }
        log(id, "$ " + cmd.joinToString(" "))
        thread(name = "qemu-$id") {
            try {
                val p = ProcessBuilder(cmd).redirectErrorStream(true).directory(filesDir).start()
                procs[id] = p
                running.update { it + (id to System.currentTimeMillis()) }
                p.inputStream.bufferedReader().forEachLine { log(id, it) }
                log(id, "[proses berhenti, kode ${p.waitFor()}]")
            } catch (e: Exception) {
                log(id, "[gagal menjalankan: ${e.message}]")
            } finally {
                procs.remove(id)
                running.update { it - id }
                if (procs.isEmpty()) stopSelf()
            }
        }
    }

    override fun onDestroy() {
        procs.values.forEach { it.destroy() }
        super.onDestroy()
    }
}
