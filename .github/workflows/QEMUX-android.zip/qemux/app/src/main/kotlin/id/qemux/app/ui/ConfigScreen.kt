package id.qemux.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import id.qemux.app.data.Arch
import id.qemux.app.data.VmConfig
import kotlin.math.roundToInt

private val RamSteps = listOf(256, 512, 1024, 2048, 3072, 4096, 6144, 8192)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun <T> Segmented(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(ButtonGroupDefaults.ConnectedSpaceBetween)) {
        options.forEachIndexed { i, o ->
            val shapes = when {
                options.size == 1 -> ToggleButtonDefaults.shapes()
                i == 0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                i == options.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
            }
            ToggleButton(
                checked = o == selected, onCheckedChange = { onSelect(o) }, shapes = shapes,
                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
            ) {
                if (o == selected) { Icon(Icons.Rounded.Check, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
                Text(label(o))
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(32.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun ValueRow(label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.headlineMedium, color = cs.primary)
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun ConfigScreen(
    initial: VmConfig,
    isRunning: Boolean,
    onBack: () -> Unit,
    onSave: (VmConfig) -> Unit,
    onDelete: () -> Unit,
    onStart: (VmConfig) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var vm by remember(initial.id) { mutableStateOf(initial) }
    val ramIdx = RamSteps.indexOf(vm.ramMb).let { if (it < 0) 3 else it }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(Modifier.fillMaxSize().background(cs.background)) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = top + 16.dp, bottom = 140.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FilledTonalIconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Kembali")
            }
            Column {
                Text("KONFIGURASI VM", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                Text(vm.name.ifBlank { "Tanpa nama" }, style = MaterialTheme.typography.headlineMedium)
            }
            Section("Umum") {
                OutlinedTextField(vm.name, { vm = vm.copy(name = it) }, label = { Text("Nama") },
                    singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
            }
            Section("Prosesor") {
                Segmented(Arch.entries, vm.arch, { it.label }) { vm = vm.copy(arch = it, machine = it.machines.first()) }
                if (vm.arch.machines.size > 1)
                    Segmented(vm.arch.machines, vm.machine, { it }) { vm = vm.copy(machine = it) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("TCG multi-thread", style = MaterialTheme.typography.titleMedium)
                        Text("Lebih cepat di CPU multi-core", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    }
                    Switch(
                        checked = vm.mttcg, onCheckedChange = { vm = vm.copy(mttcg = it) },
                        thumbContent = if (vm.mttcg) {
                            { Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
                        } else null,
                    )
                }
            }
            Section("Memori & core") {
                ValueRow("Memori RAM", ramLabel(RamSteps[ramIdx]))
                Slider(ramIdx.toFloat(), { vm = vm.copy(ramMb = RamSteps[it.roundToInt()]) },
                    valueRange = 0f..(RamSteps.lastIndex).toFloat(), steps = RamSteps.size - 2)
                ValueRow("Core CPU", vm.cores.toString())
                Slider(vm.cores.toFloat(), { vm = vm.copy(cores = it.roundToInt()) }, valueRange = 1f..8f, steps = 6)
            }
            Section("Penyimpanan") {
                OutlinedTextField(vm.diskFile, { vm = vm.copy(diskFile = it) }, label = { Text("Disk (mis. ubuntu.qcow2)") },
                    singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(vm.isoFile, { vm = vm.copy(isoFile = it) }, label = { Text("ISO (opsional)") },
                    singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
                Text("File dibaca dari folder Android/data/id.qemux.app/files/images", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            TextButton(onClick = onDelete, colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("Hapus VM ini") }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, cs.background)))
                .navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 20.dp, top = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Button(
                onClick = { onStart(vm) }, enabled = !isRunning,
                modifier = Modifier.weight(1f).height(68.dp),
                shape = RoundedCornerShape(34.dp, 10.dp, 10.dp, 34.dp),
            ) {
                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(10.dp))
                Text(if (isRunning) "Sedang berjalan" else "Mulai VM", style = MaterialTheme.typography.titleMedium)
            }
            FilledIconButton(
                onClick = { onSave(vm) }, modifier = Modifier.size(68.dp),
                shape = RoundedCornerShape(10.dp, 34.dp, 34.dp, 10.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer),
            ) { Icon(Icons.Rounded.Save, contentDescription = "Simpan konfigurasi") }
        }
    }
}
