package id.qemux.app.data

import org.json.JSONObject
import java.util.UUID

enum class Arch(val label: String, val binary: String, val machines: List<String>, val cpu: String) {
    X86_64("x86_64", "libqemu-system-x86_64.so", listOf("q35", "pc"), "qemu64"),
    AARCH64("ARM64", "libqemu-system-aarch64.so", listOf("virt"), "cortex-a72"),
    RISCV64("RISC-V", "libqemu-system-riscv64.so", listOf("virt"), "rv64"),
}

data class VmConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "VM Baru",
    val arch: Arch = Arch.X86_64,
    val machine: String = "q35",
    val cores: Int = 2,
    val ramMb: Int = 2048,
    val mttcg: Boolean = true,
    val diskFile: String = "",
    val isoFile: String = "",
    val vncPort: Int = 5900,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("arch", arch.name).put("machine", machine)
        .put("cores", cores).put("ramMb", ramMb).put("mttcg", mttcg)
        .put("diskFile", diskFile).put("isoFile", isoFile).put("vncPort", vncPort)

    companion object {
        fun fromJson(o: JSONObject) = VmConfig(
            id = o.getString("id"),
            name = o.optString("name", "VM"),
            arch = runCatching { Arch.valueOf(o.getString("arch")) }.getOrDefault(Arch.X86_64),
            machine = o.optString("machine", "q35"),
            cores = o.optInt("cores", 2),
            ramMb = o.optInt("ramMb", 2048),
            mttcg = o.optBoolean("mttcg", true),
            diskFile = o.optString("diskFile", ""),
            isoFile = o.optString("isoFile", ""),
            vncPort = o.optInt("vncPort", 5900),
        )
    }
}
