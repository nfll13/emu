package id.qemux.app.qemu

import android.content.Context
import id.qemux.app.data.Arch
import id.qemux.app.data.VmConfig
import java.io.File

object QemuCommand {
    fun binary(ctx: Context, arch: Arch) = File(ctx.applicationInfo.nativeLibraryDir, arch.binary)
    fun shareDir(ctx: Context) = File(ctx.filesDir, "qemu-share")
    fun imagesDir(ctx: Context): File =
        (ctx.getExternalFilesDir("images") ?: File(ctx.filesDir, "images")).also { it.mkdirs() }

    fun build(ctx: Context, vm: VmConfig): List<String> {
        val images = imagesDir(ctx)
        val share = shareDir(ctx)
        val a = mutableListOf(
            binary(ctx, vm.arch).absolutePath,
            "-L", share.absolutePath,
            "-machine", vm.machine,
            "-cpu", vm.arch.cpu,
            "-smp", vm.cores.toString(),
            "-m", vm.ramMb.toString(),
            "-accel", if (vm.mttcg) "tcg,thread=multi" else "tcg,thread=single",
            "-display", "none",
            "-vnc", "127.0.0.1:${vm.vncPort - 5900}",
            "-serial", "stdio",
            "-monitor", "none",
            "-nic", "user,model=virtio-net-pci",
        )
        if (vm.diskFile.isNotBlank())
            a += listOf("-drive", "file=${File(images, vm.diskFile)},if=virtio")
        if (vm.isoFile.isNotBlank()) {
            val iso = File(images, vm.isoFile)
            if (vm.arch == Arch.X86_64) a += listOf("-cdrom", iso.absolutePath)
            else a += listOf(
                "-drive", "if=none,id=cd0,media=cdrom,file=$iso",
                "-device", "virtio-scsi-pci", "-device", "scsi-cd,drive=cd0",
            )
        }
        if (vm.arch == Arch.X86_64) {
            a += listOf("-vga", "std")
        } else {
            a += listOf("-device", "virtio-gpu-pci", "-device", "qemu-xhci",
                "-device", "usb-kbd", "-device", "usb-tablet")
            if (vm.arch == Arch.AARCH64) {
                val fw = File(share, "edk2-aarch64-code.fd")
                if (fw.exists()) a += listOf("-bios", fw.absolutePath)
            }
        }
        return a
    }
}
