package id.qemux.app

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.qemux.app.data.VmConfig
import id.qemux.app.data.VmRepository
import id.qemux.app.qemu.QemuCommand
import id.qemux.app.qemu.QemuService
import id.qemux.app.qemu.ShareInstaller
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = VmRepository(app)
    private val _vms = MutableStateFlow(repo.load())
    val vms: StateFlow<List<VmConfig>> = _vms.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) { ShareInstaller.install(app) }
    }

    /** Membuat VM baru, menyimpannya, dan mengembalikan id-nya. */
    fun create(): String {
        val used = _vms.value.map { it.vncPort }.toSet()
        val port = generateSequence(5900) { it + 1 }.first { it !in used }
        val vm = VmConfig(name = "VM Baru ${_vms.value.size + 1}", vncPort = port)
        commit(_vms.value + vm)
        return vm.id
    }

    fun save(vm: VmConfig) = commit(_vms.value.map { if (it.id == vm.id) vm else it })
    fun delete(id: String) = commit(_vms.value.filterNot { it.id == id })

    fun start(vm: VmConfig) {
        val ctx = getApplication<Application>()
        val i = Intent(ctx, QemuService::class.java)
            .setAction(QemuService.ACTION_START)
            .putExtra(QemuService.EXTRA_ID, vm.id)
            .putStringArrayListExtra(QemuService.EXTRA_CMD, ArrayList(QemuCommand.build(ctx, vm)))
        ContextCompat.startForegroundService(ctx, i)
    }

    fun stop(id: String) {
        val ctx = getApplication<Application>()
        ctx.startService(
            Intent(ctx, QemuService::class.java)
                .setAction(QemuService.ACTION_STOP)
                .putExtra(QemuService.EXTRA_ID, id)
        )
    }

    private fun commit(list: List<VmConfig>) {
        _vms.update { list }
        repo.save(list)
    }
}
