package id.qemux.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import id.qemux.app.data.Arch
import id.qemux.app.data.VmConfig
import id.qemux.app.qemu.QemuCommand
import kotlinx.coroutines.delay
import kotlin.math.abs

internal fun ramLabel(mb: Int) = if (mb >= 1024 && mb % 1024 == 0) "${mb / 1024} GB" else "$mb MB"

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
internal fun vmShape(id: String): androidx.compose.ui.graphics.Shape {
    val shapes = listOf(
        MaterialShapes.Cookie9Sided, MaterialShapes.Cookie6Sided, MaterialShapes.Sunny,
        MaterialShapes.Clover4Leaf, MaterialShapes.Flower,
    )
    return shapes[abs(id.hashCode()) % shapes.size].toShape()
}

@Composable
private fun rememberElapsed(since: Long): String {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(since) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val s = ((now - since) / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun HomeScreen(
    vms: List<VmConfig>,
    running: Map<String, Long>,
    onConfig: (VmConfig) -> Unit,
    onStart: (VmConfig) -> Unit,
    onStop: (String) -> Unit,
    onConsole: (VmConfig) -> Unit,
    onNew: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    var showInfo by remember { mutableStateOf(false) }
    val shown = vms.filter {
        it.name.contains(query, ignoreCase = true) && when (filter) {
            1 -> it.id in running
            2 -> it.id !in running
            else -> true
        }
    }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(Modifier.fillMaxSize().background(cs.background)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp, top + 24.dp, 20.dp, 150.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column {
                    Text("Mesin Virtual", style = MaterialTheme.typography.displaySmall, color = cs.onBackground)
                    Text("${vms.size} VM · ${running.size} sedang berjalan",
                        style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant)
                }
            }
            item {
                TextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Cari mesin virtual") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true, shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = cs.surfaceContainer, unfocusedContainerColor = cs.surfaceContainer,
                    ),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Semua", "Berjalan", "Berhenti").forEachIndexed { i, label ->
                        FilterChip(
                            selected = filter == i, onClick = { filter = i },
                            label = { Text(label) },
                            leadingIcon = if (filter == i) {
                                { Icon(Icons.Rounded.Check, null, Modifier.size(18.dp)) }
                            } else null,
                            shape = RoundedCornerShape(14.dp),
                        )
                    }
                }
            }
            if (shown.isEmpty()) item {
                Text(
                    if (vms.isEmpty()) "Belum ada mesin virtual. Ketuk + untuk membuatnya." else "Tidak ada hasil.",
                    color = cs.onSurfaceVariant, modifier = Modifier.padding(vertical = 24.dp),
                )
            }
            items(shown, key = { it.id }) { vm ->
                VmCard(vm, running[vm.id], { onConfig(vm) }, { onStart(vm) }, { onStop(vm.id) }, { onConsole(vm) })
            }
        }

        HorizontalFloatingToolbar(
            expanded = true,
            floatingActionButton = {
                FloatingToolbarDefaults.VibrantFloatingActionButton(onClick = onNew) {
                    Icon(Icons.Rounded.Add, contentDescription = "VM baru")
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp),
        ) {
            FilledTonalIconButton(onClick = {}) { Icon(Icons.Rounded.Computer, contentDescription = "Mesin") }
            IconButton(onClick = { showInfo = true }) { Icon(Icons.Rounded.Memory, contentDescription = "Status QEMU") }
        }
    }
    if (showInfo) QemuInfoDialog { showInfo = false }
}

@Composable
private fun QemuInfoDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Status binary QEMU") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Arch.entries.forEach { a ->
                    val ok = QemuCommand.binary(ctx, a).exists()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(if (ok) Icons.Rounded.Check else Icons.Rounded.Close, null)
                        Text("${a.label}: " + if (ok) "siap" else "tidak ditemukan (${a.binary})")
                    }
                }
            }
        },
    )
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun VmCard(
    vm: VmConfig, since: Long?,
    onConfig: () -> Unit, onStart: () -> Unit, onStop: () -> Unit, onConsole: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val on = since != null
    val content = if (on) cs.onPrimary else cs.onSurface
    Surface(
        onClick = onConfig, shape = RoundedCornerShape(if (on) 36.dp else 32.dp),
        color = if (on) cs.primary else cs.surfaceContainer, contentColor = content,
    ) {
        Column(Modifier.padding(if (on) 20.dp else 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(if (on) 60.dp else 52.dp).clip(vmShape(vm.id))
                        .background(if (on) cs.tertiaryContainer else cs.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Computer, null,
                        tint = if (on) cs.onTertiaryContainer else cs.onPrimaryContainer)
                }
                Column(Modifier.weight(1f)) {
                    Text(vm.name, style = if (on) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium)
                    Text("${vm.arch.label} · ${ramLabel(vm.ramMb)} · ${vm.cores} core",
                        style = MaterialTheme.typography.bodyMedium, color = content.copy(alpha = 0.85f))
                }
                if (!on) FilledIconButton(onClick = onStart, shape = RoundedCornerShape(20.dp), modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Mulai ${vm.name}")
                }
            }
            if (since != null) {
                Surface(shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = 0.18f), contentColor = content) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF7CF2B0)))
                        Text("Berjalan · ${rememberElapsed(since)}", style = MaterialTheme.typography.labelLarge)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = onConsole, modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(26.dp, 8.dp, 8.dp, 26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = cs.onPrimary, contentColor = cs.primary),
                    ) { Text("Konsol & VNC", style = MaterialTheme.typography.titleMedium) }
                    FilledIconButton(
                        onClick = onStop, modifier = Modifier.width(72.dp).height(52.dp),
                        shape = RoundedCornerShape(8.dp, 26.dp, 26.dp, 8.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0x33FFFFFF), contentColor = cs.onPrimary),
                    ) { Icon(Icons.Rounded.Stop, contentDescription = "Hentikan ${vm.name}") }
                }
            }
        }
    }
}
