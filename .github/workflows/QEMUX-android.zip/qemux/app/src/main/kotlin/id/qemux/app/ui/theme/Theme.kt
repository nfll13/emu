package id.qemux.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val Light = lightColorScheme(
    primary = Color(0xFF5A3DCC), onPrimary = Color.White,
    primaryContainer = Color(0xFFE5DEFF), onPrimaryContainer = Color(0xFF20005F),
    secondaryContainer = Color(0xFFE5DEFF), onSecondaryContainer = Color(0xFF20005F),
    tertiary = Color(0xFF9B4425), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFB59F), onTertiaryContainer = Color(0xFF3A0B00),
    background = Color(0xFFFCF9FF), onBackground = Color(0xFF1D1B22),
    surface = Color(0xFFFCF9FF), onSurface = Color(0xFF1D1B22),
    surfaceVariant = Color(0xFFE6E0EE), onSurfaceVariant = Color(0xFF5E5A6B),
    surfaceContainer = Color(0xFFF1ECF8), surfaceContainerHigh = Color(0xFFEBE5F3),
    surfaceContainerHighest = Color(0xFFE6E0EE),
    outline = Color(0xFF8C869B), outlineVariant = Color(0xFFCAC4D6),
    inverseSurface = Color(0xFF2B2736), inverseOnSurface = Color(0xFFE6E0F2),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFCBBEFF), onPrimary = Color(0xFF2F119B),
    primaryContainer = Color(0xFF4524B3), onPrimaryContainer = Color(0xFFE5DEFF),
    secondaryContainer = Color(0xFF4A4458), onSecondaryContainer = Color(0xFFE5DEFF),
    tertiary = Color(0xFFFFB59F), onTertiary = Color(0xFF5A1C06),
    tertiaryContainer = Color(0xFF7B3016), onTertiaryContainer = Color(0xFFFFDBD0),
    background = Color(0xFF141318), onBackground = Color(0xFFE6E0E9),
    surface = Color(0xFF141318), onSurface = Color(0xFFE6E0E9),
    surfaceVariant = Color(0xFF49454F), onSurfaceVariant = Color(0xFFCAC4D6),
    surfaceContainer = Color(0xFF211F26), surfaceContainerHigh = Color(0xFF2B2930),
    surfaceContainerHighest = Color(0xFF36343B),
    outline = Color(0xFF948F9E), outlineVariant = Color(0xFF49454F),
    inverseSurface = Color(0xFFE6E0E9), inverseOnSurface = Color(0xFF2B2736),
)

private val Type = Typography().copy(
    displaySmall = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 42.sp, lineHeight = 44.sp, letterSpacing = (-1.2).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 34.sp, lineHeight = 38.sp, letterSpacing = (-1).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 24.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun QemuxTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialExpressiveTheme(
        colorScheme = if (dark) Dark else Light,
        motionScheme = MotionScheme.expressive(),
        typography = Type,
        content = content,
    )
}
