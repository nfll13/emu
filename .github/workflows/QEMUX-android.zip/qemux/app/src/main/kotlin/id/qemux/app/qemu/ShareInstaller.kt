package id.qemux.app.qemu

import android.content.Context
import android.content.res.AssetManager
import java.io.File

object ShareInstaller {
    fun install(ctx: Context) = runCatching {
        val dest = QemuCommand.shareDir(ctx)
        if (File(dest, ".done").exists()) return@runCatching
        if (ctx.assets.list("qemu-share").isNullOrEmpty()) return@runCatching
        copy(ctx.assets, "qemu-share", dest)
        File(dest, ".done").writeText("1")
    }

    private fun copy(am: AssetManager, path: String, dest: File) {
        val children = am.list(path) ?: return
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            am.open(path).use { i -> dest.outputStream().use { i.copyTo(it) } }
        } else {
            dest.mkdirs()
            children.forEach { copy(am, "$path/$it", File(dest, it)) }
        }
    }
}
