# QemuLab

Frontend Android untuk menjalankan mesin virtual QEMU, dengan UI **Material 3 Expressive**
(Jetpack Compose `material3:1.4.0`): `MaterialExpressiveTheme` + `MotionScheme.expressive()`,
`LargeFlexibleTopAppBar`, `LoadingIndicator`, `LinearWavyProgressIndicator`, bentuk `MaterialShapes` (cookie),
dynamic color.

## Cara build
1. Buka folder ini di **Android Studio** (Ladybug atau lebih baru). Gradle wrapper dibuat otomatis saat sync.
2. **Taruh binary QEMU** (lihat bawah), lalu `Build > Build APK(s)`.

## Binary QEMU (wajib)
APK tidak bisa menjalankan VM tanpa binary QEMU untuk Android arm64. Aplikasi mencari binary di
`nativeLibraryDir`, jadi namanya harus berawalan `lib` dan berakhiran `.so`:

```
app/src/main/jniLibs/arm64-v8a/libqemu-system-x86_64.so    # qemu-system-x86_64
app/src/main/jniLibs/arm64-v8a/libqemu-system-aarch64.so   # qemu-system-aarch64
```
Jika QEMU kamu butuh library lain (glib, pixman, dll.), taruh juga di folder yang sama sebagai `lib*.so`
(aplikasi sudah mengatur `LD_LIBRARY_PATH`). Binary bisa diambil dari build QEMU untuk Termux
(`pkg install qemu-system-x86-64` lalu salin berkasnya) atau di-cross-compile dengan Android NDK.
Pastikan lisensi GPL QEMU dipenuhi bila APK didistribusikan.

Untuk VM ARM64, taruh firmware UEFI di `files/firmware/QEMU_EFI.fd` (di dalam data aplikasi).

## Cara pakai
- **VM baru** → atur nama, arsitektur, RAM, CPU, ukuran disk (raw sparse), pilih ISO (disalin ke penyimpanan aplikasi).
- **Jalankan** → QEMU dijalankan dengan `-vnc 127.0.0.1:N`. Sambungkan aplikasi klien VNC ke `127.0.0.1:590N`
  (port tampil di kartu VM). Output serial muncul di panel Konsol.

## Batasan saat ini
- Belum ada viewer VNC bawaan; gunakan klien VNC eksternal.
- Emulasi memakai TCG (tanpa KVM), jadi lambat. Jangan beri RAM terlalu besar.
- Proses berjalan di proses aplikasi; Android bisa mematikannya saat di latar belakang
  (langkah berikutnya: foreground service).
- Kode ini belum dikompilasi di lingkungan pembuatnya; kemungkinan perlu penyesuaian kecil pada
  nama API Material 3 Expressive bila versi library berbeda.
