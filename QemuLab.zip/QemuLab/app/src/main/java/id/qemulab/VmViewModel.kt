package id.qemulab

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.qemulab.data.VmConfig
import id.qemulab.data.VmStore
import id.qemulab.qemu.QemuRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

class VmViewModel(app: Application) : AndroidViewModel(app) {

    private val store = VmStore(app)
    val runner = QemuRunner(app)

    private val imagesDir = File(app.filesDir, "images").apply { mkdirs() }

    private val _vms = MutableStateFlow(store.load())
    val vms: StateFlow<List<VmConfig>> = _vms.asStateFlow()

    /** Nama berkas yang sedang disalin (null bila tidak ada). */
    private val _importing = MutableStateFlow<String?>(null)
    val importing: StateFlow<String?> = _importing.asStateFlow()

    fun newConfig() = VmConfig(vncDisplay = (_vms.value.maxOfOrNull { it.vncDisplay } ?: 0) + 1)

    fun save(vm: VmConfig) {
        viewModelScope.launch(Dispatchers.IO) {
            var v = vm
            if (v.diskPath.isBlank()) {
                val f = File(imagesDir, "${v.id}.img")
                RandomAccessFile(f, "rw").use { it.setLength(v.diskGb * 1024L * 1024L * 1024L) }
                v = v.copy(diskPath = f.absolutePath)
            }
            _vms.update { list ->
                if (list.any { it.id == v.id }) list.map { if (it.id == v.id) v else it } else list + v
            }
            store.save(_vms.value)
        }
    }

    fun delete(vm: VmConfig) {
        runner.stop(vm.id)
        viewModelScope.launch(Dispatchers.IO) {
            File(vm.diskPath).delete()
            _vms.update { list -> list.filterNot { it.id == vm.id } }
            store.save(_vms.value)
        }
    }

    fun start(vm: VmConfig) = runner.start(vm)
    fun stop(vm: VmConfig) = runner.stop(vm.id)

    /** Salin ISO/disk pilihan pengguna ke penyimpanan aplikasi supaya QEMU bisa membukanya lewat path. */
    fun importImage(uri: Uri, onDone: (String) -> Unit) {
        viewModelScope.launch {
            val resolver = getApplication<Application>().contentResolver
            val name = withContext(Dispatchers.IO) {
                runCatching {
                    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                        if (it.moveToFirst()) it.getString(0) else null
                    }
                }.getOrNull()
            } ?: "image-${System.currentTimeMillis()}.iso"
            _importing.value = name
            val path = withContext(Dispatchers.IO) {
                val out = File(imagesDir, name)
                resolver.openInputStream(uri)?.use { input ->
                    out.outputStream().use { input.copyTo(it) }
                }
                out.absolutePath
            }
            _importing.value = null
            onDone(path)
        }
    }
}
