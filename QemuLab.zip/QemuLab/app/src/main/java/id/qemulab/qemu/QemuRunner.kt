package id.qemulab.qemu

import android.content.Context
import id.qemulab.data.Arch
import id.qemulab.data.VmConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * Menjalankan binary QEMU yang dibundel sebagai library native
 * (app/src/main/jniLibs/arm64-v8a/libqemu-system-*.so).
 * Binary di nativeLibraryDir adalah satu-satunya lokasi yang boleh di-exec di Android 10+.
 */
class QemuRunner(private val context: Context) {

    private val processes = ConcurrentHashMap<String, Process>()

    private val _running = MutableStateFlow<Set<String>>(emptySet())
    val running: StateFlow<Set<String>> = _running.asStateFlow()

    private val _logs = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    val logs: StateFlow<Map<String, List<String>>> = _logs.asStateFlow()

    private val nativeDir get() = context.applicationInfo.nativeLibraryDir

    fun binaryFor(arch: Arch) = File(nativeDir, arch.binary)
    fun hasBinary(arch: Arch) = binaryFor(arch).exists()

    fun buildCommand(vm: VmConfig): List<String> {
        val a = mutableListOf(
            binaryFor(vm.arch).absolutePath,
            "-m", vm.ramMb.toString(),
            "-smp", vm.cores.toString(),
            "-serial", "stdio",
            "-monitor", "none",
            "-vnc", "127.0.0.1:${vm.vncDisplay}",
            "-netdev", "user,id=n0",
            "-device", "virtio-net-pci,netdev=n0",
        )
        when (vm.arch) {
            Arch.X86_64 -> a += listOf(
                "-machine", "q35", "-cpu", "max", "-accel", "tcg,thread=multi",
                "-device", "VGA", "-device", "qemu-xhci", "-device", "usb-tablet",
            )
            Arch.AARCH64 -> {
                a += listOf(
                    "-machine", "virt", "-cpu", "cortex-a72", "-accel", "tcg,thread=multi",
                    "-device", "virtio-gpu-pci", "-device", "qemu-xhci",
                    "-device", "usb-kbd", "-device", "usb-tablet",
                )
                val fw = File(context.filesDir, "firmware/QEMU_EFI.fd")
                if (fw.exists()) a += listOf("-bios", fw.absolutePath)
            }
        }
        if (vm.diskPath.isNotBlank() && File(vm.diskPath).exists()) {
            a += listOf("-drive", "file=${vm.diskPath},if=virtio,format=raw")
        }
        if (vm.isoPath.isNotBlank() && File(vm.isoPath).exists()) {
            a += when (vm.arch) {
                Arch.X86_64 -> listOf("-cdrom", vm.isoPath, "-boot", "d")
                Arch.AARCH64 -> listOf(
                    "-device", "virtio-scsi-pci",
                    "-drive", "if=none,id=cd0,media=cdrom,file=${vm.isoPath}",
                    "-device", "scsi-cd,drive=cd0",
                )
            }
        }
        a += vm.extraArgs.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        return a
    }

    fun start(vm: VmConfig) {
        if (processes.containsKey(vm.id)) return
        _logs.update { it + (vm.id to emptyList()) }

        val bin = binaryFor(vm.arch)
        if (!bin.exists()) {
            log(vm.id, "✗ Binary ${bin.name} tidak ditemukan.")
            log(vm.id, "  Taruh di app/src/main/jniLibs/arm64-v8a/ lalu build ulang (lihat README).")
            return
        }
        val cmd = buildCommand(vm)
        log(vm.id, "$ " + cmd.joinToString(" "))
        log(vm.id, "VNC: 127.0.0.1:${vm.vncPort}")
        try {
            val pb = ProcessBuilder(cmd).redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = nativeDir
            pb.directory(context.filesDir)
            val p = pb.start()
            processes[vm.id] = p
            _running.update { it + vm.id }
            thread(name = "qemu-${vm.id.take(6)}", isDaemon = true) {
                p.inputStream.bufferedReader().forEachLine { log(vm.id, it) }
                val code = p.waitFor()
                log(vm.id, "— proses berhenti (kode $code)")
                processes.remove(vm.id)
                _running.update { it - vm.id }
            }
        } catch (e: Exception) {
            log(vm.id, "✗ Gagal menjalankan: ${e.message}")
        }
    }

    fun stop(id: String) {
        val p = processes[id] ?: return
        p.destroy()
        thread(isDaemon = true) {
            Thread.sleep(2000)
            if (p.isAlive) p.destroyForcibly()
        }
    }

    private fun log(id: String, line: String) {
        _logs.update { m -> m + (id to (m[id].orEmpty() + line).takeLast(500)) }
    }
}
