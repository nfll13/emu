package id.qemulab.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.qemulab.data.Arch
import id.qemulab.data.VmConfig
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun EditVmSheet(
    initial: VmConfig,
    importing: String?,
    onImport: (Uri, (String) -> Unit) -> Unit,
    onSave: (VmConfig) -> Unit,
    onDismiss: () -> Unit,
) {
    var draft by remember { mutableStateOf(initial) }
    val isNew = initial.diskPath.isBlank()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onImport(uri) { path -> draft = draft.copy(isoPath = path) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                if (isNew) "VM baru" else "Ubah VM",
                style = MaterialTheme.typography.headlineMedium,
            )

            OutlinedTextField(
                value = draft.name,
                onValueChange = { draft = draft.copy(name = it) },
                label = { Text("Nama") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Arsitektur", style = MaterialTheme.typography.titleSmall)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                Arch.entries.forEachIndexed { i, a ->
                    SegmentedButton(
                        selected = draft.arch == a,
                        onClick = { draft = draft.copy(arch = a) },
                        shape = SegmentedButtonDefaults.itemShape(i, Arch.entries.size),
                    ) { Text(a.label) }
                }
            }

            LabeledSlider("RAM", "${draft.ramMb} MB", draft.ramMb.toFloat(), 512f..8192f) {
                draft = draft.copy(ramMb = ((it / 256f).roundToInt() * 256).coerceAtLeast(512))
            }
            LabeledSlider("CPU", "${draft.cores} inti", draft.cores.toFloat(), 1f..8f) {
                draft = draft.copy(cores = it.roundToInt().coerceIn(1, 8))
            }
            if (isNew) {
                LabeledSlider("Disk", "${draft.diskGb} GB", draft.diskGb.toFloat(), 2f..64f) {
                    draft = draft.copy(diskGb = it.roundToInt().coerceIn(2, 64))
                }
            } else {
                Text(
                    "Disk: ${draft.diskGb} GB (tetap)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Text("Image ISO", style = MaterialTheme.typography.titleSmall)
            OutlinedButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                enabled = importing == null,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    if (draft.isoPath.isBlank()) "Pilih berkas ISO…"
                    else File(draft.isoPath).name
                )
            }
            if (importing != null) {
                Text("Menyalin $importing…", style = MaterialTheme.typography.bodySmall)
                LinearWavyProgressIndicator(Modifier.fillMaxWidth())
            }

            OutlinedTextField(
                value = draft.extraArgs,
                onValueChange = { draft = draft.copy(extraArgs = it) },
                label = { Text("Argumen QEMU tambahan") },
                supportingText = { Text("Contoh: -device virtio-rng-pci") },
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = { onSave(draft) },
                enabled = draft.name.isNotBlank() && importing == null,
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) { Text(if (isNew) "Buat VM" else "Simpan") }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: String,
    current: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column {
        androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(value, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = current, onValueChange = onChange, valueRange = range)
    }
}
