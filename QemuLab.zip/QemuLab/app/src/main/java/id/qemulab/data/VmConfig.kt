package id.qemulab.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class Arch(val label: String, val short: String, val binary: String) {
    X86_64("x86_64", "x86", "libqemu-system-x86_64.so"),
    AARCH64("ARM64", "ARM", "libqemu-system-aarch64.so"),
}

data class VmConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "VM baru",
    val arch: Arch = Arch.X86_64,
    val ramMb: Int = 1024,
    val cores: Int = 2,
    val diskGb: Int = 8,
    val diskPath: String = "",
    val isoPath: String = "",
    val vncDisplay: Int = 1,
    val extraArgs: String = "",
) {
    val vncPort get() = 5900 + vncDisplay
}

class VmStore(context: Context) {
    private val file = File(context.filesDir, "vms.json")

    fun load(): List<VmConfig> = runCatching {
        val arr = JSONArray(file.readText())
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            VmConfig(
                id = o.getString("id"),
                name = o.getString("name"),
                arch = Arch.valueOf(o.getString("arch")),
                ramMb = o.getInt("ramMb"),
                cores = o.getInt("cores"),
                diskGb = o.getInt("diskGb"),
                diskPath = o.getString("diskPath"),
                isoPath = o.getString("isoPath"),
                vncDisplay = o.getInt("vncDisplay"),
                extraArgs = o.getString("extraArgs"),
            )
        }
    }.getOrDefault(emptyList())

    fun save(list: List<VmConfig>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("name", it.name).put("arch", it.arch.name)
                    .put("ramMb", it.ramMb).put("cores", it.cores).put("diskGb", it.diskGb)
                    .put("diskPath", it.diskPath).put("isoPath", it.isoPath)
                    .put("vncDisplay", it.vncDisplay).put("extraArgs", it.extraArgs)
            )
        }
        file.writeText(arr.toString())
    }
}
