package id.qemulab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import id.qemulab.data.VmConfig
import id.qemulab.ui.ConsoleSheet
import id.qemulab.ui.EditVmSheet
import id.qemulab.ui.HomeScreen
import id.qemulab.ui.QemuLabTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { QemuLabTheme { QemuLabApp() } }
    }
}

@Composable
fun QemuLabApp(vm: VmViewModel = viewModel()) {
    val vms by vm.vms.collectAsStateWithLifecycle()
    val running by vm.runner.running.collectAsStateWithLifecycle()
    val logs by vm.runner.logs.collectAsStateWithLifecycle()
    val importing by vm.importing.collectAsStateWithLifecycle()

    var editing by remember { mutableStateOf<VmConfig?>(null) }
    var consoleId by remember { mutableStateOf<String?>(null) }

    HomeScreen(
        vms = vms,
        running = running,
        binaryOk = vm.runner::hasBinary,
        onAdd = { editing = vm.newConfig() },
        onEdit = { editing = it },
        onDelete = vm::delete,
        onStart = { vm.start(it); consoleId = it.id },
        onStop = vm::stop,
        onConsole = { consoleId = it.id },
    )

    editing?.let { cfg ->
        EditVmSheet(
            initial = cfg,
            importing = importing,
            onImport = vm::importImage,
            onSave = { vm.save(it); editing = null },
            onDismiss = { editing = null },
        )
    }

    consoleId?.let { id ->
        vms.firstOrNull { it.id == id }?.let { cfg ->
            ConsoleSheet(
                vm = cfg,
                lines = logs[id].orEmpty(),
                isRunning = id in running,
                onStop = { vm.stop(cfg) },
                onDismiss = { consoleId = null },
            )
        }
    }
}
